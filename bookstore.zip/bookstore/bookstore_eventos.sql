-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eventos`
--

DROP TABLE IF EXISTS `eventos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eventos` (
  `eve_id` int NOT NULL AUTO_INCREMENT,
  `eve_bli_id` int NOT NULL,
  `eve_nombre` varchar(45) DEFAULT NULL,
  `eve_invitados` int DEFAULT NULL,
  `eve_fecha_hora` datetime DEFAULT NULL,
  PRIMARY KEY (`eve_id`),
  KEY `fk_Eventos_Bibliotecas1_idx` (`eve_bli_id`),
  CONSTRAINT `fk_Eventos_Bibliotecas1` FOREIGN KEY (`eve_bli_id`) REFERENCES `bibliotecas` (`bli_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventos`
--

LOCK TABLES `eventos` WRITE;
/*!40000 ALTER TABLE `eventos` DISABLE KEYS */;
INSERT INTO `eventos` VALUES (4,9,'Rolando',108,'2019-04-14 05:25:34'),(5,3,'Ailsun',166,'2021-03-19 21:11:00'),(6,7,'Filmer',155,'2022-02-04 01:55:22'),(7,7,'Isac',103,'2019-09-05 15:22:23'),(8,5,'Jarret',103,'2023-09-01 21:15:23'),(9,5,'Teressa',105,'2021-08-11 02:34:13'),(10,4,'Dominique',197,'2021-11-19 06:45:05'),(11,10,'Mendel',132,'2019-08-14 20:09:53'),(12,5,'Ludovika',119,'2022-01-02 17:24:58'),(13,4,'Sarine',105,'2021-08-09 20:43:32'),(14,4,'Farr',161,'2019-04-22 02:40:06'),(15,8,'Ibbie',128,'2022-08-15 04:43:33'),(16,9,'Curtis',177,'2021-08-18 14:47:46'),(17,4,'Joannes',174,'2019-11-29 07:00:13'),(18,3,'Melva',151,'2024-04-29 14:17:09'),(19,1,'Brooks',110,'2021-07-27 15:38:57'),(20,1,'Imelda',102,'2018-06-10 02:57:54'),(21,8,'Aimil',101,'2021-10-21 11:17:01'),(22,7,'Doy',153,'2020-03-28 16:16:47'),(23,4,'Norene',135,'2019-12-23 04:40:50'),(24,10,'Sascha',171,'2021-01-31 20:41:30'),(25,10,'Arlie',139,'2019-09-25 10:36:44'),(26,8,'Matias',104,'2022-01-13 09:07:09'),(27,1,'Elsy',185,'2018-08-19 04:21:49'),(28,1,'Ludovico',171,'2018-10-21 03:41:11'),(29,7,'Schuyler',191,'2022-08-02 03:53:07'),(30,6,'Zacharie',175,'2018-01-30 01:47:25'),(31,8,'Dena',141,'2019-12-23 17:23:21'),(32,3,'Nannie',168,'2024-02-01 00:30:32'),(33,6,'Amble',149,'2024-01-27 21:01:45'),(34,7,'Merci',182,'2020-07-05 19:35:31'),(35,4,'Raddie',190,'2023-09-28 05:54:31'),(36,8,'Ragnar',142,'2021-02-28 17:55:57'),(37,9,'Sauncho',162,'2024-08-07 13:42:27'),(38,6,'Gaylor',178,'2018-04-18 01:49:39'),(39,10,'Jamison',108,'2022-12-19 08:54:40'),(40,1,'Alikee',179,'2024-10-30 10:24:19'),(41,1,'Fernanda',144,'2021-08-09 20:50:47'),(42,4,'Whit',138,'2018-04-06 20:24:58'),(43,9,'Rozelle',167,'2018-10-12 18:59:47'),(44,8,'Darrell',186,'2021-11-19 15:28:02'),(45,4,'Lianna',188,'2023-04-22 04:58:18'),(46,3,'Leicester',116,'2023-09-28 19:45:18'),(47,4,'Simone',180,'2022-05-12 16:08:44'),(48,2,'Bendix',159,'2023-07-16 13:41:02'),(49,8,'Brandais',123,'2022-03-15 03:06:55'),(50,6,'Bruno',171,'2024-11-09 22:49:20'),(51,3,'Alyss',191,'2019-08-28 03:10:25'),(52,3,'Axe',161,'2021-08-01 21:30:49'),(53,1,'Robinet',200,'2021-09-06 18:02:33'),(54,6,'Phil',112,'2020-11-30 20:23:02'),(55,3,'Rolph',120,'2024-04-08 13:35:07'),(56,1,'Teodorico',139,'2020-01-20 03:22:50'),(57,9,'Nani',180,'2024-12-29 02:53:06'),(58,3,'Billie',135,'2023-09-30 07:58:56'),(59,1,'Barby',164,'2019-10-12 06:55:41'),(60,6,'Dorine',183,'2024-09-21 04:36:40'),(61,7,'Sherri',105,'2018-04-29 15:39:37'),(62,7,'Boonie',139,'2023-06-23 19:41:20'),(63,4,'Ignatius',187,'2022-07-17 00:26:22'),(64,3,'Theodore',130,'2018-02-18 17:04:18'),(65,6,'Diana',181,'2021-07-24 10:26:36'),(66,9,'Ericka',197,'2021-12-18 13:45:29'),(67,2,'Asia',182,'2020-01-27 19:32:54'),(68,4,'Mandie',183,'2024-06-05 10:51:24'),(69,4,'Maddy',200,'2021-05-28 04:30:33'),(70,1,'Scott',128,'2020-03-30 22:53:49'),(71,10,'Van',200,'2024-09-30 11:21:21'),(72,8,'Kalvin',198,'2020-06-11 13:36:14'),(73,1,'Darrelle',100,'2023-05-17 21:21:16'),(74,3,'Cleopatra',145,'2019-09-21 06:15:01'),(75,5,'Belle',184,'2018-10-05 19:00:05'),(76,2,'Hieronymus',195,'2020-04-15 13:48:16'),(77,3,'Germayne',154,'2024-09-25 19:20:01'),(78,8,'Hy',170,'2023-10-19 13:45:13'),(79,7,'Kippy',147,'2022-11-29 15:59:15'),(80,5,'Siffre',162,'2018-05-11 13:40:46'),(81,2,'Leola',172,'2024-12-29 17:05:05'),(82,2,'Willem',166,'2020-06-30 02:25:36'),(83,10,'Dannie',130,'2023-08-20 05:29:06'),(84,8,'Elfie',193,'2023-02-20 11:59:29'),(85,2,'Micaela',169,'2022-01-20 15:38:22'),(86,9,'Pattin',132,'2018-11-08 10:11:40'),(87,2,'David',117,'2023-12-17 13:48:54'),(88,7,'Bettye',136,'2023-03-28 22:15:33'),(89,5,'Salome',172,'2022-10-21 12:02:06'),(90,4,'Kristan',157,'2021-11-07 23:22:28'),(91,10,'Benita',160,'2022-05-29 16:36:54'),(92,6,'Leon',181,'2019-11-23 05:27:32'),(93,5,'Edy',177,'2019-03-04 21:44:58'),(94,4,'Jerry',161,'2020-04-12 02:15:19'),(95,9,'Darn',172,'2019-12-21 12:21:46'),(96,5,'Bryana',191,'2020-06-01 10:58:23'),(97,5,'Cully',185,'2021-12-29 09:15:12'),(98,7,'May',149,'2020-01-19 10:58:29'),(99,3,'Cobbie',150,'2023-02-05 22:40:49'),(100,5,'Virgina',133,'2021-03-08 23:56:53'),(101,8,'Florri',119,'2021-06-18 00:43:29'),(102,6,'Glen',150,'2021-07-27 08:47:29'),(103,5,'Ker',166,'2019-10-25 09:30:13');
/*!40000 ALTER TABLE `eventos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01  0:50:44
