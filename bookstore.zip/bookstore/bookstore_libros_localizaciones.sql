-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `libros_localizaciones`
--

DROP TABLE IF EXISTS `libros_localizaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `libros_localizaciones` (
  `lib_loc_id` int NOT NULL AUTO_INCREMENT,
  `lib_loc_lib_id` int NOT NULL,
  `lib_loc_loc_id` int NOT NULL,
  PRIMARY KEY (`lib_loc_id`),
  KEY `fk_Libros_has_Localizaciones_Localizaciones1_idx` (`lib_loc_loc_id`),
  KEY `fk_Libros_has_Localizaciones_Libros1_idx` (`lib_loc_lib_id`),
  CONSTRAINT `fk_Libros_has_Localizaciones_Libros1` FOREIGN KEY (`lib_loc_lib_id`) REFERENCES `libros` (`lib_id`),
  CONSTRAINT `fk_Libros_has_Localizaciones_Localizaciones1` FOREIGN KEY (`lib_loc_loc_id`) REFERENCES `localizaciones` (`loc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `libros_localizaciones`
--

LOCK TABLES `libros_localizaciones` WRITE;
/*!40000 ALTER TABLE `libros_localizaciones` DISABLE KEYS */;
INSERT INTO `libros_localizaciones` VALUES (1,182,8),(2,163,232),(3,170,219),(4,135,66),(5,60,220),(6,199,205),(7,15,12),(8,40,84),(9,37,29),(10,13,50),(11,56,155),(12,32,93),(13,111,90),(14,185,211),(15,126,160),(16,52,214),(17,95,151),(18,69,94),(19,31,72),(20,116,169),(21,23,13),(22,9,7),(23,185,45),(24,93,22),(25,144,221),(26,47,188),(27,59,67),(28,196,50),(29,180,15),(30,165,13),(31,18,217),(32,81,200),(33,12,1),(34,92,74),(35,95,126),(36,116,178),(37,48,171),(38,65,182),(39,127,22),(40,64,25),(41,22,238),(42,61,132),(43,108,13),(44,173,243),(45,112,120),(46,177,137),(47,45,227),(48,15,124),(49,18,122),(50,123,27),(51,90,188),(52,163,65),(53,156,205),(54,103,145),(55,193,124),(56,28,24),(57,139,66),(58,117,225),(59,121,122),(60,34,91),(61,117,30),(62,17,116),(63,43,52),(64,164,60),(65,37,218),(66,161,80),(67,115,136),(68,34,179),(69,57,183),(70,60,65),(71,32,161),(72,150,128),(73,188,130),(74,4,232),(75,91,228),(76,192,56),(77,108,31),(78,4,209),(79,111,215),(80,102,104),(81,196,62),(82,7,230),(83,190,174),(84,99,19),(85,169,202),(86,143,210),(87,150,100),(88,194,43),(89,11,17),(90,168,66),(91,189,222),(92,70,92),(93,20,85),(94,122,51),(95,131,118),(96,132,196),(97,59,43),(98,48,83),(99,187,201),(100,165,37);
/*!40000 ALTER TABLE `libros_localizaciones` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01  0:50:44
