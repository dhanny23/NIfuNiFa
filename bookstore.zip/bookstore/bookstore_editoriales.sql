-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `editoriales`
--

DROP TABLE IF EXISTS `editoriales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `editoriales` (
  `edi_id` int NOT NULL AUTO_INCREMENT,
  `edi_nombre` varchar(45) DEFAULT NULL,
  `edi_fecha_publicacion` date DEFAULT NULL,
  PRIMARY KEY (`edi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `editoriales`
--

LOCK TABLES `editoriales` WRITE;
/*!40000 ALTER TABLE `editoriales` DISABLE KEYS */;
INSERT INTO `editoriales` VALUES (1,'Quirk Books','1990-03-22'),(2,'Hay House','1989-08-01'),(3,'Abrams Books','1989-09-07'),(4,'Chronicle Books','1991-12-24'),(5,'Candlewick Press','1996-06-19'),(6,'Houghton Mifflin Harcourt','1992-01-26'),(7,'Knopf Doubleday Publishing Group','1971-07-07'),(8,'Routledge','1972-04-15'),(9,'MIT Press','1997-09-25'),(10,'Vintage Books','1995-11-04'),(11,'Farrar, Straus and Giroux','1992-06-14'),(12,'Pan Macmillan','1989-10-10'),(13,'Bloomsbury Publishing','1976-02-04'),(14,'Elsevier','1977-01-29'),(15,'Pearson','1972-07-31'),(16,'Scholastic Corporation','1976-08-27'),(17,'Cambridge University Press','1978-12-23'),(18,'Wiley','1993-03-14'),(19,'Springer','1988-10-10'),(20,'Macmillan Publishers','1997-12-22'),(21,'Hachette Livre','1990-05-12'),(22,'Simon & Schuster','1995-02-22'),(23,'HarperCollins','1993-03-22'),(24,'Penguin Random House','1980-01-12'),(25,'Oxford University Press','1991-03-20');
/*!40000 ALTER TABLE `editoriales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01  0:50:42
