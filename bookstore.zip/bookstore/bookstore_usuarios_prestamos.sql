-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios_prestamos`
--

DROP TABLE IF EXISTS `usuarios_prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios_prestamos` (
  `usu_pre_id` int NOT NULL AUTO_INCREMENT,
  `usu_pre_usu_id` int NOT NULL,
  `usu_pre_pre_id` int NOT NULL,
  PRIMARY KEY (`usu_pre_id`),
  KEY `fk_Usuarios_has_Prestamos_Prestamos1_idx` (`usu_pre_pre_id`),
  KEY `fk_Usuarios_has_Prestamos_Usuarios1_idx` (`usu_pre_usu_id`),
  CONSTRAINT `fk_Usuarios_has_Prestamos_Prestamos1` FOREIGN KEY (`usu_pre_pre_id`) REFERENCES `prestamos` (`pre_id`),
  CONSTRAINT `fk_Usuarios_has_Prestamos_Usuarios1` FOREIGN KEY (`usu_pre_usu_id`) REFERENCES `usuarios` (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_prestamos`
--

LOCK TABLES `usuarios_prestamos` WRITE;
/*!40000 ALTER TABLE `usuarios_prestamos` DISABLE KEYS */;
INSERT INTO `usuarios_prestamos` VALUES (1,56,2),(2,21,43),(3,40,71),(4,5,35),(5,88,25),(6,30,69),(7,10,71),(8,74,3),(9,23,88),(10,52,11),(11,52,16),(12,93,33),(13,41,13),(14,88,40),(15,54,24),(16,10,82),(17,4,19),(18,36,60),(19,97,26),(20,63,77),(21,21,6),(22,13,7),(23,74,30),(24,20,1),(25,58,50),(26,28,22),(27,24,30),(28,58,85),(29,11,20),(30,38,32),(31,11,39),(32,3,94),(33,75,57),(34,43,17),(35,80,96),(36,34,71),(37,62,81),(38,86,47),(39,33,32),(40,79,64),(41,48,16),(42,45,99),(43,19,87),(44,25,53),(45,95,3),(46,18,30),(47,89,91),(48,16,66),(49,17,43),(50,5,88),(51,23,97),(52,42,74),(53,56,85),(54,79,78),(55,79,52),(56,71,83),(57,101,88),(58,21,27),(59,67,6),(60,78,14),(61,21,3),(62,5,82),(63,95,27),(64,45,2),(65,61,42),(66,61,90),(67,45,84),(68,95,44),(69,65,10),(70,99,11),(71,88,91),(72,9,99),(73,76,47),(74,8,64),(75,101,84),(76,28,93),(77,21,86),(78,8,70),(79,61,57),(80,100,19),(81,17,87),(82,22,24),(83,91,79),(84,60,23),(85,57,6),(86,48,38),(87,97,12),(88,31,97),(89,39,78),(90,42,6),(91,64,2),(92,69,31),(93,25,29),(94,41,2),(95,60,28),(96,25,44),(97,64,38),(98,67,83),(99,95,13),(100,53,28);
/*!40000 ALTER TABLE `usuarios_prestamos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01  0:50:43
