-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consultas`
--

DROP TABLE IF EXISTS `consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultas` (
  `con_id` int NOT NULL AUTO_INCREMENT,
  `con_bli_id` int NOT NULL,
  `con_tipo_consulta` varchar(45) DEFAULT NULL,
  `con_fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`con_id`),
  KEY `fk_Consultas_Bibliotecas1_idx` (`con_bli_id`),
  CONSTRAINT `fk_Consultas_Bibliotecas1` FOREIGN KEY (`con_bli_id`) REFERENCES `bibliotecas` (`bli_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultas`
--

LOCK TABLES `consultas` WRITE;
/*!40000 ALTER TABLE `consultas` DISABLE KEYS */;
INSERT INTO `consultas` VALUES (1,9,'aliquam non mauris morbi non lectus','2021-01-25 09:27:44'),(2,3,'dui proin leo odio porttitor id','2018-11-01 06:34:29'),(3,1,'natoque penatibus et magnis dis parturient','2020-02-09 16:00:22'),(4,4,'molestie lorem quisque ut erat curabitur','2019-05-05 01:18:33'),(5,4,'natoque penatibus et magnis dis','2024-04-19 12:10:28'),(6,7,'dictumst etiam faucibus cursus urna ut','2021-10-06 10:51:40'),(7,2,'adipiscing elit proin risus praesent','2021-12-17 07:39:51'),(8,5,'congue diam id ornare imperdiet','2022-11-07 04:52:45'),(9,2,'in quam fringilla rhoncus mauris','2024-11-25 23:53:45'),(10,9,'amet erat nulla tempus vivamus in','2019-12-26 07:37:07'),(11,7,'potenti in eleifend quam a odio','2023-06-08 21:53:45'),(12,6,'sed ante vivamus tortor duis mattis','2020-03-04 15:47:40'),(13,3,'ac est lacinia nisi venenatis tristique','2023-04-14 12:50:19'),(14,2,'pede justo lacinia eget tincidunt','2022-03-11 16:26:50'),(15,10,'curae donec pharetra magna vestibulum aliquet','2020-09-07 23:03:35'),(16,10,'faucibus orci luctus et ultrices','2021-02-11 10:10:01'),(17,7,'donec dapibus duis at velit eu','2024-12-12 21:08:34'),(18,9,'eu massa donec dapibus duis at','2018-07-22 02:19:10'),(19,6,'porttitor lacus at turpis donec posuere','2022-04-04 02:46:12'),(20,7,'luctus cum sociis natoque penatibus et','2022-05-19 11:02:20'),(21,7,'nisl aenean lectus pellentesque eget nunc','2024-05-23 05:41:25'),(22,1,'ultrices phasellus id sapien in','2018-09-02 10:42:39'),(23,6,'erat id mauris vulputate elementum nullam','2020-09-07 01:55:12'),(24,8,'aliquet pulvinar sed nisl nunc','2019-03-21 12:30:38'),(25,7,'elit ac nulla sed vel','2024-03-11 23:43:59'),(26,4,'donec diam neque vestibulum eget','2019-01-14 15:30:59'),(27,4,'natoque penatibus et magnis dis','2023-07-15 23:43:45'),(28,6,'donec ut mauris eget massa tempor','2021-10-16 04:29:47'),(29,8,'ut mauris eget massa tempor','2024-11-02 06:40:34'),(30,6,'pede justo eu massa donec dapibus','2020-04-11 09:33:52'),(31,6,'felis sed lacus morbi sem','2020-08-05 07:47:49'),(32,9,'ut massa volutpat convallis morbi odio','2023-06-12 13:44:42'),(33,2,'mattis egestas metus aenean fermentum donec','2019-04-01 18:29:40'),(34,6,'commodo placerat praesent blandit nam nulla','2021-05-19 20:43:24'),(35,2,'orci mauris lacinia sapien quis libero','2024-10-13 03:54:45'),(36,10,'suspendisse ornare consequat lectus in est','2021-04-30 16:57:11'),(37,5,'massa volutpat convallis morbi odio odio','2023-03-31 08:14:26'),(38,2,'nunc purus phasellus in felis','2022-01-11 19:01:49'),(39,3,'purus eu magna vulputate luctus','2023-03-11 12:08:21'),(40,9,'pretium iaculis diam erat fermentum justo','2022-11-08 11:13:23'),(41,2,'vel accumsan tellus nisi eu orci','2022-03-06 21:00:42'),(42,3,'pede posuere nonummy integer non velit','2024-06-09 17:05:17'),(43,6,'donec vitae nisi nam ultrices libero','2020-09-20 21:34:37'),(44,2,'aliquam sit amet diam in magna','2023-06-14 18:22:43'),(45,8,'feugiat et eros vestibulum ac','2021-04-23 10:35:36'),(46,1,'urna ut tellus nulla ut','2024-08-04 03:09:35'),(47,7,'mauris lacinia sapien quis libero nullam','2022-07-01 04:14:58'),(48,9,'hac habitasse platea dictumst maecenas','2024-08-05 00:44:14'),(49,2,'blandit ultrices enim lorem ipsum','2019-02-04 02:59:10'),(50,2,'pretium quis lectus suspendisse potenti','2018-12-29 04:30:46'),(51,10,'nulla pede ullamcorper augue a','2023-08-03 21:39:16'),(52,4,'nibh quisque id','2023-07-13 08:17:51'),(53,4,'mus vivamus','2018-05-14 01:20:08'),(54,1,'orci luctus','2019-05-22 01:54:02'),(55,5,'natoque penatibus et','2019-10-19 22:01:30'),(56,3,'lorem ipsum dolor','2021-05-31 15:24:51'),(57,4,'quam turpis adipiscing','2018-10-09 03:30:09'),(58,1,'eros elementum pellentesque','2021-11-25 11:02:14'),(59,8,'est lacinia','2022-11-04 20:56:34'),(60,9,'vehicula consequat morbi','2021-11-28 17:27:32'),(61,5,'morbi a ipsum','2023-02-21 05:00:02'),(62,6,'tristique tortor','2022-02-14 23:03:19'),(63,10,'proin interdum','2024-06-08 08:37:05'),(64,8,'donec odio','2023-03-03 15:39:48'),(65,7,'mi pede malesuada','2021-06-29 18:08:37'),(66,10,'volutpat dui maecenas','2022-11-04 20:40:30'),(67,2,'diam in','2021-05-21 23:59:04'),(68,3,'tortor quis turpis','2021-04-12 01:33:13'),(69,6,'luctus ultricies eu','2018-08-05 07:02:04'),(70,7,'mauris sit amet','2023-12-06 22:07:15'),(71,2,'ut rhoncus aliquet','2024-03-14 16:52:19'),(72,5,'cursus urna','2024-01-12 07:30:13'),(73,9,'ut massa','2020-01-16 15:15:07'),(74,5,'nibh fusce','2024-02-21 06:47:50'),(75,8,'ultrices enim lorem','2019-03-16 12:19:39'),(76,10,'libero quis','2020-01-27 03:17:19'),(77,5,'bibendum felis sed','2021-11-22 20:29:23'),(78,7,'feugiat non pretium','2023-09-01 12:17:59'),(79,7,'amet eros','2018-03-18 13:57:03'),(80,3,'vestibulum quam sapien','2021-04-12 07:22:04'),(81,2,'donec semper','2019-04-15 05:36:19'),(82,7,'tortor sollicitudin mi','2021-10-10 18:03:36'),(83,6,'nec condimentum','2024-11-07 14:32:21'),(84,9,'sapien a','2019-10-19 04:43:50'),(85,2,'nibh quisque','2024-03-10 03:46:55'),(86,5,'porttitor lorem id','2022-12-04 11:12:41'),(87,3,'vestibulum velit id','2020-09-09 12:05:40'),(88,6,'id ornare imperdiet','2020-01-06 13:23:48'),(89,6,'adipiscing elit proin','2019-04-17 01:22:43'),(90,6,'nisl nunc nisl','2022-03-06 08:36:37'),(91,6,'vel sem','2019-11-16 03:20:04'),(92,1,'mollis molestie','2024-03-14 19:26:25'),(93,9,'etiam pretium iaculis','2024-06-29 01:22:03'),(94,3,'donec semper sapien','2022-07-26 19:54:05'),(95,4,'vestibulum ante','2022-05-19 21:14:06'),(96,1,'erat id','2018-07-31 12:41:14'),(97,6,'pellentesque volutpat dui','2024-06-07 10:06:35'),(98,6,'et eros','2019-08-21 06:07:35'),(99,10,'luctus tincidunt nulla','2024-12-29 09:20:51'),(100,3,'in ante','2024-09-23 15:04:48');
/*!40000 ALTER TABLE `consultas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01  0:50:43
