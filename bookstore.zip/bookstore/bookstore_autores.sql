-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `autores`
--

DROP TABLE IF EXISTS `autores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autores` (
  `aut_id` int NOT NULL AUTO_INCREMENT,
  `aut_edi_id` int NOT NULL,
  `aut_nombre` varchar(45) DEFAULT NULL,
  `aut_apellido` varchar(45) DEFAULT NULL,
  `aut_nacionalidad` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`aut_id`),
  KEY `fk_Autores_Editoriales1_idx` (`aut_edi_id`),
  CONSTRAINT `fk_Autores_Editoriales1` FOREIGN KEY (`aut_edi_id`) REFERENCES `editoriales` (`edi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autores`
--

LOCK TABLES `autores` WRITE;
/*!40000 ALTER TABLE `autores` DISABLE KEYS */;
INSERT INTO `autores` VALUES (4,22,'Nessy','Baily','Russia'),(5,7,'Hayyim','Punter','Portugal'),(6,21,'Averell','Lipson','Ukraine'),(7,15,'Roarke','Guerreiro','China'),(8,24,'Alameda','Saggers','Indonesia'),(9,10,'Al','Motton','China'),(10,6,'Denys','MacGown','Russia'),(11,21,'Flint','Dallander','Indonesia'),(12,16,'Reina','Plain','Nigeria'),(13,25,'Tybi','Strippel','China'),(14,18,'Gene','Frays','Canada'),(15,4,'Payton','Goodbarne','China'),(16,3,'Baxy','Blankman','Azerbaijan'),(17,14,'Amalita','Genge','China'),(18,18,'Sheila-kathryn','Puddefoot','Finland'),(19,16,'Barbette','Faires','Czech Republic'),(20,1,'Becka','Graine','Russia'),(21,5,'Brooks','Briton','Indonesia'),(22,13,'Xenos','Strathern','Indonesia'),(23,20,'Vivianne','Rozenbaum','Sweden'),(24,3,'Alaine','Graysmark','Portugal'),(25,4,'Burtie','Rolfe','Indonesia'),(26,19,'Lynelle','Mitcheson','Kyrgyzstan'),(27,6,'Bobbie','Smallbone','Mexico'),(28,16,'Dolley','Mattsson','Indonesia'),(29,18,'Franklyn','Rowswell','France'),(30,9,'Vite','Vowels','Colombia'),(31,17,'Dmitri','Efford','China'),(32,3,'Brock','Fairbairn','Indonesia'),(33,24,'Hestia','Nasey','United States'),(34,3,'Denney','Kleingrub','China'),(35,2,'Gerianne','Edger','Nigeria'),(36,18,'Helena','Bloom','Iran'),(37,13,'Hurleigh','Redman','Brazil'),(38,5,'Sebastian','Coston','China'),(39,5,'Micheline','Southouse','Macedonia'),(40,17,'Cyndie','Beste','Vanuatu'),(41,23,'Suzy','Mander','China'),(42,24,'Jennine','Angless','Moldova'),(43,2,'Aldin','Merryman','Ukraine'),(44,7,'Caryn','Card','Indonesia'),(45,13,'Garvin','Lathee','Sweden'),(46,8,'Wynn','Hyams','China'),(47,22,'Tandi','Hapgood','Russia'),(48,19,'Burr','Nelthropp','Kazakhstan'),(49,1,'Curry','McComiskie','Indonesia'),(50,21,'Sherwynd','Lacrouts','China'),(51,22,'Any','Issakov','Syria'),(52,20,'Tomaso','Ties','China'),(53,18,'Charita','Macveigh','Greece'),(54,5,'Luci','Inge','China'),(55,20,'Wright','Taylorson','Zimbabwe'),(56,8,'Raymond','Wauchope','Indonesia'),(57,24,'Lorrin','Phalip','Sweden'),(58,18,'Wallie','MacGinley','Colombia'),(59,20,'Valerie','Edy','Albania'),(60,4,'Harlene','McCraine','Moldova'),(61,22,'Bibby','de Werk','China'),(62,16,'Lyda','Cawkwell','China'),(63,2,'Fielding','Weildish','Malaysia'),(64,10,'Angil','Monelli','Indonesia'),(65,12,'Rikki','Alcorn','Kenya'),(66,1,'Gretta','Handover','Palestinian Territory'),(67,8,'Rania','Clarkson','Ukraine'),(68,18,'Noe','Bathowe','China'),(69,15,'Jilleen','Fligg','France'),(70,12,'Norah','Armfirld','China'),(71,24,'Angel','Aloshikin','Brazil'),(72,2,'Ram','Demoge','Italy'),(73,10,'Regen','Taft','Nigeria'),(74,11,'Alexis','Carayol','Argentina'),(75,23,'Jesse','Lyttle','China'),(76,12,'Ninon','Blevin','China'),(77,8,'Donia','Giacomasso','Indonesia'),(78,23,'Sonnie','Gow','Philippines'),(79,10,'Michele','McFaell','Indonesia'),(80,5,'Nert','Scoyne','Thailand'),(81,16,'Luca','Tumpane','Poland'),(82,14,'Brant','Al Hirsi','Morocco'),(83,25,'Porter','Romanelli','Poland'),(84,3,'Christa','Olerenshaw','Poland'),(85,21,'Jennine','Checchi','Portugal'),(86,24,'Madalyn','Snoad','Argentina'),(87,19,'Raina','O\'Fallowne','Central African Republic'),(88,9,'Tomasine','Runnett','Thailand'),(89,23,'Nelly','Veschambes','Japan'),(90,21,'Elva','Huster','Honduras'),(91,20,'Chane','Dimmock','Guatemala'),(92,21,'Hedi','Blenkinship','Indonesia'),(93,2,'Vivien','Maith','Costa Rica'),(94,4,'Issi','Mustin','Ukraine'),(95,24,'Shantee','Muzzullo','China'),(96,7,'Cleavland','Chaplain','Kenya'),(97,20,'Almeria','Quadling','Bangladesh'),(98,25,'Humfrey','Gregh','Mexico'),(99,24,'Milzie','Dummer','Mali'),(100,4,'Viviene','McChruiter','Russia'),(101,14,'Simone','Holbarrow','Philippines'),(102,18,'Rene','McWhinnie','Peru'),(103,9,'Adriane','Kunneke','China');
/*!40000 ALTER TABLE `autores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01  0:50:43
